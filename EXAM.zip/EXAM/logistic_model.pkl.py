# Importing necessary libraries
import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Loading the MNIST dataset
mnist = fetch_openml('mnist_784', version=1, cache=True, as_frame=False)
X, y = mnist['data'], mnist['target'].astype(np.uint8)

# Splitting the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardizing the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Model 1: Logistic Regression
logistic_model = LogisticRegression(max_iter=100)
logistic_model.fit(X_train_scaled, y_train)

# Predicting with the logistic regression model
y_pred_logistic = logistic_model.predict(X_test_scaled)

# Calculating accuracy for logistic regression
accuracy_logistic = accuracy_score(y_test, y_pred_logistic)
print("Accuracy of Logistic Regression:", accuracy_logistic)

# Model 2: Random Forest Classifier
random_forest_model = RandomForestClassifier(n_estimators=100)
random_forest_model.fit(X_train_scaled, y_train)

# Predicting with the random forest model
y_pred_rf = random_forest_model.predict(X_test_scaled)

# Calculating accuracy for random forest
accuracy_rf = accuracy_score(y_test, y_pred_rf)
print("Accuracy of Random Forest Classifier:", accuracy_rf)

